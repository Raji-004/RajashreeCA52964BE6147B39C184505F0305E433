def linear_search_product(products, target_product):
    # Initialize an empty list to store the indices of occurrences
    indices = []

    # Loop through the list of products
    for i, product in enumerate(products):
        # Check if the current product matches the target product
        if product == target_product:
            # If it matches, add the index to the list
            indices.append(i)

    return indices

# Example usage:
products = ["apple", "banana", "orange", "apple", "grape"]
target_product = "apple"
result = linear_search_product(products, target_product)
print("Indices of", target_product, ":", result)
